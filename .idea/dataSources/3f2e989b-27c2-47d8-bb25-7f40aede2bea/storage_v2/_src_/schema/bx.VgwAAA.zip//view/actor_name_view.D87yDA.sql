create view actor_name_view as
  select
    `bx`.`actor`.`first_name` AS `first_name_v`,
    `bx`.`actor`.`last_name`  AS `last_name_v`
  from `bx`.`actor`;

